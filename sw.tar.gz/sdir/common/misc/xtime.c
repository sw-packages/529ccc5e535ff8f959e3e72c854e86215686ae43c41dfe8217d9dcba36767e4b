#include <config.h>
#define XTIME_INLINE _GL_EXTERN_INLINE
#include "xtime.h"
